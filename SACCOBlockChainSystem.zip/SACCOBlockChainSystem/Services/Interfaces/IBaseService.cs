﻿namespace SACCOBlockChainSystem.Services.Interfaces
{
    public class IBaseService
    {
    }
}
